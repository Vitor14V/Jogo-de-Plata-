
/**
 * Represents the state of a single planting plot.
 */
export enum PlotState {
  Empty = 'EMPTY',
  Growing = 'GROWING',
  ReadyToHarvest = 'READY_TO_HARVEST',
  Locked = 'LOCKED',
}

/**
 * Defines the rarity levels for crops.
 */
export enum Rarity {
  Comum = 'Comum',
  Incomum = 'Incomum',
  Raro = 'Raro',
  Lendario = 'Lendário',
}

/**
 * Defines the Tailwind CSS classes for each rarity.
 */
export const RARITY_STYLES: Record<Rarity, string> = {
  [Rarity.Comum]: 'text-gray-600 font-medium',
  [Rarity.Incomum]: 'text-green-600 font-bold',
  [Rarity.Raro]: 'text-blue-600 font-bold',
  [Rarity.Lendario]: 'text-purple-600 font-bold',
};


/**
 * Represents the properties of a plantable crop.
 */
export interface Crop {
  name: string;
  emoji: string;
  growthTime: number; // in seconds
  sellPrice: number; // silver gained when selling
  price: number; // silver cost to buy
  rarity: Rarity;
  description: string;
  origin: string;
}


/**
 * Represents a single planting plot on the farm.
 */
export interface Plot {
  id: number;
  state: PlotState;
  cropType: string | null;
  plantTime: number | null;
}

/**
 * Represents the player's inventory, separating seeds and harvested crops.
 */
export interface PlayerInventory {
  sementes: Record<string, number>; // cropKey -> quantity
  colheitas: Record<string, number>; // cropKey -> quantity
}


/**
 * Represents the structure of the player's saved data.
 */
export interface PlayerData {
  name: string;
  silver: number;
  plots: Plot[]; 
  inventory: PlayerInventory;
  upgrades: string[];
}

/**
 * Enum to manage which screen is currently visible to the player.
 */
export enum GameScreen {
  MainMenu,
  PlayerCreation,
  Farm,
  Credits
}
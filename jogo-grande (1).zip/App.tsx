
import React, { useState, useEffect, useCallback } from 'react';
import { GameScreen, PlayerData, PlotState } from './types';
import { loadPlayerData, savePlayerData } from './services/storageService';
import MainMenu from './components/MainMenu';
import PlayerCreation from './components/PlayerCreation';
import Farm from './components/Farm';
import Credits from './components/Credits';
import ChangelogModal from './components/ChangelogModal';

const INITIAL_PLOTS_COUNT = 6;

const App: React.FC = () => {
  const [screen, setScreen] = useState<GameScreen>(GameScreen.MainMenu);
  const [playerData, setPlayerData] = useState<PlayerData | null>(null);
  const [saveExists, setSaveExists] = useState<boolean>(false);
  const [isChangelogOpen, setIsChangelogOpen] = useState(false);

  useEffect(() => {
    let data = loadPlayerData();
    if (data) {
      // MIGRATION LOGIC
      // 1. Inventory: ensure `sementes` and `colheitas` exist
      const oldInventory = (data.inventory || {}) as any;
      data.inventory = {
        sementes: oldInventory.sementes || oldInventory || {},
        colheitas: oldInventory.colheitas || {},
      };
      
      // 2. Plots: ensure valid array, migrate old states, and ensure correct count
      if (!data.plots || !Array.isArray(data.plots)) {
        data.plots = [];
      }

      data.plots = data.plots.map(p => {
        const oldState = (p as any).state;
        const newP: any = {
          id: p.id,
          state: p.state || PlotState.Empty,
          cropType: p.cropType || null,
          plantTime: p.plantTime || null,
        };
        if (oldState === 'PLANTED') {
           newP.state = p.plantTime ? PlotState.Growing : PlotState.Empty;
        }
        return newP;
      });

      if (data.plots.length < INITIAL_PLOTS_COUNT) {
        const existingIds = new Set(data.plots.map(p => p.id));
        let nextId = 1;
        while (data.plots.length < INITIAL_PLOTS_COUNT) {
          while (existingIds.has(nextId)) {
            nextId++;
          }
          data.plots.push({ id: nextId, state: PlotState.Locked, cropType: null, plantTime: null });
          existingIds.add(nextId);
        }
      }
      
      // 3. Cleanup deprecated top-level properties
      if ((data as any).crops) {
          delete (data as any).crops;
      }

      setPlayerData(data);
      setSaveExists(true);
    } else {
      setSaveExists(false);
    }
  }, []);
  
  const updateAndSavePlayerData = useCallback((data: PlayerData) => {
    setPlayerData(data);
    savePlayerData(data);
  }, []);

  const handleStartNewGame = useCallback(() => {
    setScreen(GameScreen.PlayerCreation);
  }, []);

  const handleContinueGame = useCallback(() => {
    const data = loadPlayerData();
    if (data) {
      setPlayerData(data); // The data is already migrated by the initial useEffect
      setScreen(GameScreen.Farm);
    }
  }, []);

  const handleShowCredits = useCallback(() => {
    setScreen(GameScreen.Credits);
  }, []);

  const handleShowUpdates = useCallback(() => {
    setIsChangelogOpen(true);
  }, []);

  const handleCreatePlayer = useCallback((name: string) => {
    if (name.trim()) {
      const newPlayerData: PlayerData = {
        name: name.trim(),
        silver: 20, // Start with some silver to buy things
        plots: [
          { id: 1, state: PlotState.Empty, cropType: null, plantTime: null },
          { id: 2, state: PlotState.Empty, cropType: null, plantTime: null },
          { id: 3, state: PlotState.Locked, cropType: null, plantTime: null },
          { id: 4, state: PlotState.Locked, cropType: null, plantTime: null },
          { id: 5, state: PlotState.Locked, cropType: null, plantTime: null },
          { id: 6, state: PlotState.Locked, cropType: null, plantTime: null },
        ],
        inventory: { 
          sementes: { wheat: 10 }, // Start with 10 wheat seeds
          colheitas: {}, // Start with empty harvests
        },
        upgrades: [],
      };
      updateAndSavePlayerData(newPlayerData);
      setSaveExists(true);
      setScreen(GameScreen.Farm);
    }
  }, [updateAndSavePlayerData]);
  
  const handleGoToMenu = useCallback(() => {
    // When returning to the menu, we check again if the save exists
    const data = loadPlayerData();
    setSaveExists(!!data);
    setScreen(GameScreen.MainMenu);
  }, []);

  const renderScreen = () => {
    switch (screen) {
      case GameScreen.PlayerCreation:
        return <PlayerCreation onCreatePlayer={handleCreatePlayer} onBack={handleGoToMenu} />;
      case GameScreen.Farm:
        return playerData ? <Farm playerData={playerData} onGoToMenu={handleGoToMenu} onUpdatePlayerData={updateAndSavePlayerData} /> : <MainMenu onStart={handleStartNewGame} onContinue={handleContinueGame} onCredits={handleShowCredits} onUpdates={handleShowUpdates} continueDisabled={!saveExists} />;
      case GameScreen.Credits:
        return <Credits onGoToMenu={handleGoToMenu} />;
      case GameScreen.MainMenu:
      default:
        return <MainMenu onStart={handleStartNewGame} onContinue={handleContinueGame} onCredits={handleShowCredits} onUpdates={handleShowUpdates} continueDisabled={!saveExists} />;
    }
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center p-4 text-center text-gray-800">
      <ChangelogModal isOpen={isChangelogOpen} onClose={() => setIsChangelogOpen(false)} />
      {renderScreen()}
    </div>
  );
};

export default App;


import type { PlayerData } from '../types';

const SAVE_KEY = 'silverfarm_save';

/**
 * Saves player data to localStorage.
 * @param data The player data to save.
 */
export const savePlayerData = (data: PlayerData): void => {
  try {
    const dataString = JSON.stringify(data);
    localStorage.setItem(SAVE_KEY, dataString);
  } catch (error) {
    console.error("Failed to save game data:", error);
  }
};

/**
 * Loads player data from localStorage.
 * @returns The loaded player data, or null if no data is found or an error occurs.
 */
export const loadPlayerData = (): PlayerData | null => {
  try {
    const dataString = localStorage.getItem(SAVE_KEY);
    if (dataString) {
      return JSON.parse(dataString) as PlayerData;
    }
    return null;
  } catch (error) {
    console.error("Failed to load game data:", error);
    return null;
  }
};

/**
 * Clears all player data from localStorage.
 */
export const clearPlayerData = (): void => {
  try {
    localStorage.removeItem(SAVE_KEY);
  } catch (error) {
    console.error("Failed to clear game data:", error);
  }
};

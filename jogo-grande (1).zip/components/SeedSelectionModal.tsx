
import React from 'react';
import type { Crop, PlayerInventory } from '../types';
import RetroButton from './RetroButton';

interface SeedSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSeed: (cropKey: string) => void;
  crops: Record<string, Crop>;
  inventory: PlayerInventory;
}

const SeedSelectionModal: React.FC<SeedSelectionModalProps> = ({ isOpen, onClose, onSelectSeed, crops, inventory }) => {
  if (!isOpen) {
    return null;
  }

  const ownedSeeds = Object.entries(crops).filter(([key]) => inventory.sementes[key] > 0);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 animate-fade-in" role="dialog" aria-modal="true">
      <div className="bg-amber-100 p-6 border-8 border-green-800 rounded-lg max-w-sm w-full text-center shadow-2xl">
        <h2 className="text-2xl md:text-3xl font-bold text-green-800 mb-6">Plantar Semente</h2>
        <div className="flex flex-col gap-4 max-h-96 overflow-y-auto pr-2">
          {ownedSeeds.length > 0 ? (
            ownedSeeds.map(([key, crop]) => (
            <button
              key={key}
              onClick={() => onSelectSeed(key)}
              className="flex items-center justify-between w-full p-3 bg-green-200 border-4 border-green-600 rounded-md hover:bg-green-300 transform transition-transform hover:scale-105"
              aria-label={`Plantar ${crop.name}`}
            >
              <div className="flex items-center gap-4">
                <span className="text-4xl" aria-hidden="true">{crop.emoji}</span>
                <div className="text-left">
                  <p className="font-bold text-lg">{crop.name}</p>
                  <p className="text-sm text-gray-700">Lucro: {crop.sellPrice - crop.price} 🪙 | Tempo: {crop.growthTime}s</p>
                </div>
              </div>
              <span className="font-bold text-xl pr-2">x{inventory.sementes[key]}</span>
            </button>
            ))
          ) : (
            <p className="text-gray-700 my-4">Você não tem sementes! Visite a loja para comprar algumas.</p>
          )}
        </div>
        <div className="mt-8">
          <RetroButton onClick={onClose} className="bg-gray-500 hover:bg-gray-600 w-full">
            Cancelar
          </RetroButton>
        </div>
      </div>
    </div>
  );
};

export default SeedSelectionModal;

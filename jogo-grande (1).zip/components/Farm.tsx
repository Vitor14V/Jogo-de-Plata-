
import React, { useState, useEffect } from 'react';
import type { PlayerData, Plot } from '../types';
import { PlotState } from '../types';
import RetroButton from './RetroButton';
import SeedSelectionModal from './SeedSelectionModal';
import ShopModal from './ShopModal';
import InventoryModal from './InventoryModal';
import { CROP_DATA } from '../data/crops';

interface FarmProps {
  playerData: PlayerData;
  onGoToMenu: () => void;
  onUpdatePlayerData: (data: PlayerData) => void;
}

const PLOT_UNLOCK_COST = 100; // Cost in silver to unlock a plot

const Farm: React.FC<FarmProps> = ({ playerData, onGoToMenu, onUpdatePlayerData }) => {
  const [showSaveMessage, setShowSaveMessage] = useState(false);
  const [harvestMessage, setHarvestMessage] = useState<{ text: string; id: number } | null>(null);
  const [plantModalInfo, setPlantModalInfo] = useState<{ isOpen: boolean; plotId: number | null }>({ isOpen: false, plotId: null });
  const [isShopOpen, setIsShopOpen] = useState(false);
  const [isInventoryOpen, setIsInventoryOpen] = useState(false);
  const [, setTime] = useState(Date.now());

  useEffect(() => {
    const interval = setInterval(() => {
      // Game Tick Logic - runs every second to update plant growth and timers.
      const now = Date.now();
      
      // Optimization: Only check for updates if there's at least one plot growing.
      const hasGrowingPlots = playerData.plots.some(p => p.state === PlotState.Growing);

      if (hasGrowingPlots) {
          let needsStateUpdate = false;
          
          // Logic to check if any growing plant is ready for harvest.
          // This calculation is based on real time, so progress is made even if the game is closed.
          const updatedPlots = playerData.plots.map(plot => {
            if (plot.state === PlotState.Growing && plot.plantTime && plot.cropType) {
              const crop = CROP_DATA[plot.cropType];
              // tempoTotal (in ms) from crop data (which is in seconds)
              const growthDuration = crop.growthTime * 1000;
              // plantadoEm (the timestamp when the seed was planted)
              const plantTime = plot.plantTime;
              
              // If the time elapsed since planting is greater than the required growth time...
              if (now >= plantTime + growthDuration) {
                needsStateUpdate = true;
                // ...the plot is now ready to be harvested.
                return { ...plot, state: PlotState.ReadyToHarvest };
              }
            }
            return plot;
          });
    
          if (needsStateUpdate) {
            // Save the new state to localStorage to persist progress.
            onUpdatePlayerData({ ...playerData, plots: updatedPlots });
          }
      }
      
      // Force a re-render every second to keep all countdown timers live.
      setTime(now);
    }, 1000);

    return () => clearInterval(interval);
  }, [playerData, onUpdatePlayerData]);

  const handleSave = () => {
    onUpdatePlayerData(playerData);
    setShowSaveMessage(true);
    setTimeout(() => setShowSaveMessage(false), 2000);
  };
  
  const handleOpenPlantMenu = (plotId: number) => {
    setPlantModalInfo({ isOpen: true, plotId });
  };

  const handleSelectSeed = (cropKey: string) => {
    if (plantModalInfo.plotId === null) return;

    const currentSeedCount = playerData.inventory.sementes[cropKey] || 0;
    if (currentSeedCount <= 0) {
      console.error("Attempted to plant a seed that is not in inventory.");
      setPlantModalInfo({ isOpen: false, plotId: null });
      return;
    }

    const newInventory = { ...playerData.inventory };
    newInventory.sementes = { ...newInventory.sementes };
    newInventory.sementes[cropKey] = currentSeedCount - 1;

    const newPlots = playerData.plots.map(p =>
      p.id === plantModalInfo.plotId ? { ...p, state: PlotState.Growing, cropType: cropKey, plantTime: Date.now() } : p
    );
    onUpdatePlayerData({ ...playerData, plots: newPlots, inventory: newInventory });
    setPlantModalInfo({ isOpen: false, plotId: null });
  };
  
  const handleHarvest = (plotId: number) => {
    const plot = playerData.plots.find(p => p.id === plotId);
    if (!plot || !plot.cropType) return;

    const crop = CROP_DATA[plot.cropType];
    const cropKey = plot.cropType;
    
    // Add harvested item to inventory
    const newInventory = { ...playerData.inventory };
    newInventory.colheitas = { ...newInventory.colheitas };
    newInventory.colheitas[cropKey] = (newInventory.colheitas[cropKey] || 0) + 1;
    
    // Show feedback message for harvested item
    setHarvestMessage({ text: `+1 ${crop.name} ${crop.emoji}`, id: Date.now() });
    setTimeout(() => setHarvestMessage(null), 2000);

    // Reset the plot to be empty
    const newPlots = playerData.plots.map(p =>
      p.id === plotId ? { ...p, state: PlotState.Empty, cropType: null, plantTime: null } : p
    );
    
    // Update player data
    onUpdatePlayerData({ ...playerData, plots: newPlots, inventory: newInventory });
  };

  const handleUnlockPlot = (plotId: number) => {
    if (playerData.silver < PLOT_UNLOCK_COST) {
      alert(`Prata insuficiente! Você precisa de ${PLOT_UNLOCK_COST} 🪙.`);
      return;
    }

    const newPlots = playerData.plots.map(p =>
      p.id === plotId ? { ...p, state: PlotState.Empty } : p
    );

    onUpdatePlayerData({
      ...playerData,
      plots: newPlots,
      silver: playerData.silver - PLOT_UNLOCK_COST,
    });
  };

  const renderPlot = (plot: Plot) => {
    const plotContent = () => {
        switch (plot.state) {
            case PlotState.Empty:
                return (
                    <div className="flex flex-col items-center justify-center text-center h-full">
                        <div className="text-lg">Vazio</div>
                        <div className="w-full mt-auto">
                            <RetroButton onClick={() => handleOpenPlantMenu(plot.id)} className="bg-green-600 hover:bg-green-700 text-sm p-2 w-full">
                                Plantar
                            </RetroButton>
                        </div>
                    </div>
                );
            case PlotState.Growing: {
                if (!plot.cropType || plot.plantTime === null) return null;
                const crop = CROP_DATA[plot.cropType];
                
                // Core real-time calculation:
                // tempoRestante = tempoTotal - (agora - plantadoEm)
                const timePassed = (Date.now() - plot.plantTime) / 1000; // in seconds
                const remainingSeconds = Math.max(0, Math.ceil(crop.growthTime - timePassed));
                
                const formatTime = (seconds: number) => {
                    const minutes = Math.floor(seconds / 60);
                    const secs = seconds % 60;
                    return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
                };

                return (
                    <div className="flex flex-col items-center justify-center text-center h-full">
                        <span className="text-5xl" role="img" aria-label={crop.name}>{crop.emoji}</span>
                        <p className="text-sm mt-2">{crop.name}</p>
                        <p className="text-lg font-bold mt-1">{formatTime(remainingSeconds)}</p>
                    </div>
                );
            }
            case PlotState.ReadyToHarvest: {
                if (!plot.cropType) return null;
                const readyCrop = CROP_DATA[plot.cropType];
                return (
                    <div className="flex flex-col items-center justify-center text-center h-full">
                         <span className="text-5xl animate-bounce-slow" role="img" aria-label={readyCrop.name}>{readyCrop.emoji}</span>
                         <p className="text-sm mt-1 font-bold">Pronto!</p>
                         <div className="w-full mt-auto">
                            <RetroButton onClick={() => handleHarvest(plot.id)} className="bg-yellow-500 hover:bg-yellow-600 text-sm p-2 w-full">
                                Colher
                            </RetroButton>
                        </div>
                    </div>
                );
            }
            case PlotState.Locked: {
                 return (
                    <div className="flex flex-col items-center justify-center text-center h-full bg-black bg-opacity-40">
                         <span className="text-5xl" role="img" aria-label="Bloqueado">🔐</span>
                         <div className="w-full mt-auto">
                            <RetroButton 
                                onClick={() => handleUnlockPlot(plot.id)} 
                                className="bg-gray-700 hover:bg-gray-600 text-sm p-2 w-full"
                                disabled={playerData.silver < PLOT_UNLOCK_COST}
                            >
                                {PLOT_UNLOCK_COST} 🪙
                            </RetroButton>
                        </div>
                    </div>
                );
            }
            default:
                return null;
        }
    };
    
    return (
        <div key={plot.id} className="w-36 h-40 bg-orange-900 border-4 border-yellow-700 flex flex-col items-center justify-center p-2 text-white shadow-inner transition-all duration-300">
            {plotContent()}
        </div>
    );
  };
  
  return (
    <>
      <SeedSelectionModal 
        isOpen={plantModalInfo.isOpen}
        onClose={() => setPlantModalInfo({ isOpen: false, plotId: null })}
        onSelectSeed={handleSelectSeed}
        crops={CROP_DATA}
        inventory={playerData.inventory}
      />
      <ShopModal
        isOpen={isShopOpen}
        onClose={() => setIsShopOpen(false)}
        playerData={playerData}
        onUpdatePlayerData={onUpdatePlayerData}
        crops={CROP_DATA}
      />
      <InventoryModal
        isOpen={isInventoryOpen}
        onClose={() => setIsInventoryOpen(false)}
        inventory={playerData.inventory}
        crops={CROP_DATA}
      />
      <div className="flex flex-col items-center justify-between gap-4 w-full h-full max-w-4xl bg-green-200 p-4 border-8 border-green-800 animate-fade-in md:h-auto md:rounded-lg">
        {/* Header with Player Info */}
        <header className="w-full flex justify-between items-center bg-amber-200 p-3 border-4 border-gray-800 text-gray-800 rounded-md">
          <h1 className="text-lg md:text-2xl font-bold truncate pr-2">
            Minha Plantação
          </h1>
          <div className="relative text-lg md:text-2xl font-bold flex-shrink-0">
            {harvestMessage && (
              <span 
                key={harvestMessage.id} 
                className="absolute right-0 -top-8 text-green-500 font-bold animate-float-up whitespace-nowrap"
                style={{ textShadow: '2px 2px #111' }}
              >
                {harvestMessage.text}
              </span>
            )}
            <span className="flex items-center gap-2 bg-black bg-opacity-20 px-3 py-1 rounded-md text-white">
              <span>🪙</span>
              <span>{playerData.silver} prata</span>
            </span>
          </div>
        </header>

        {/* Farm Area */}
        <main className="flex-grow w-full flex items-center justify-center my-4">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 justify-items-center">
            {playerData.plots.map(renderPlot)}
          </div>
        </main>

        {/* Action Buttons */}
        <footer className="w-full grid grid-cols-2 md:grid-cols-4 gap-2 relative">
          <RetroButton onClick={() => setIsShopOpen(true)} className="bg-yellow-500 hover:bg-yellow-600">
            Loja
          </RetroButton>
          <RetroButton onClick={() => setIsInventoryOpen(true)} className="bg-blue-500 hover:bg-blue-600">
            Inventário
          </RetroButton>
          <RetroButton onClick={handleSave} className="bg-green-600 hover:bg-green-700">
            Salvar
          </RetroButton>
          <RetroButton onClick={onGoToMenu} className="bg-gray-500 hover:bg-gray-600">
            Sair
          </RetroButton>
          {showSaveMessage && (
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 bg-black bg-opacity-75 text-white text-sm py-1 px-3 rounded-md animate-fade-in">
                Jogo Salvo!
              </div>
            )}
        </footer>
      </div>
    </>
  );
};

export default Farm;

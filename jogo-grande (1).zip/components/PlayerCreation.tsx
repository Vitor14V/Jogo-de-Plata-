import React, { useState } from 'react';
import RetroButton from './RetroButton';

interface PlayerCreationProps {
  onCreatePlayer: (name: string) => void;
  onBack: () => void;
}

const PlayerCreation: React.FC<PlayerCreationProps> = ({ onCreatePlayer, onBack }) => {
  const [name, setName] = useState('');

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Regra: Apenas letras, números e espaços
    const sanitizedValue = e.target.value.replace(/[^a-zA-Z0-9 ]/g, '');
    setName(sanitizedValue);
  };

  const handleConfirm = () => {
    if (name.trim()) {
      onCreatePlayer(name.trim());
    }
  };

  return (
    <div className="flex flex-col items-center justify-center gap-6 w-full max-w-sm animate-fade-in">
      <h2 className="text-3xl md:text-4xl font-bold text-green-800 mb-4 text-center">
        Bem-vindo à sua fazenda!
      </h2>
      <input
        id="playerName"
        type="text"
        value={name}
        onChange={handleNameChange}
        className="w-full p-4 border-4 border-gray-800 bg-white text-lg focus:outline-none focus:ring-4 focus:ring-yellow-400 text-center"
        placeholder="Digite o nome do seu fazendeiro"
        maxLength={16}
        aria-label="Player Name Input"
      />
      <div className="w-full flex flex-col gap-4 mt-4">
        <RetroButton onClick={handleConfirm} disabled={!name.trim()} className="bg-green-600 hover:bg-green-700">
          Começar
        </RetroButton>
        <RetroButton onClick={onBack} className="bg-gray-500 hover:bg-gray-600">
          Voltar
        </RetroButton>
      </div>
    </div>
  );
};

export default PlayerCreation;
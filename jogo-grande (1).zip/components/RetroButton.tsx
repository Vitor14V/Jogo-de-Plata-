import React from 'react';

interface RetroButtonProps {
  onClick: () => void;
  children: React.ReactNode;
  disabled?: boolean;
  className?: string;
}

const RetroButton: React.FC<RetroButtonProps> = ({ onClick, children, disabled = false, className = 'bg-green-600 hover:bg-green-700' }) => {
  const baseClasses = 'w-full max-w-xs text-white p-4 text-lg md:text-xl shadow-lg transform transition-transform duration-150 ease-in-out';
  const enabledClasses = `${className} active:scale-95 hover:scale-105 cursor-pointer`;
  const disabledClasses = 'bg-gray-400 cursor-not-allowed';

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${baseClasses} ${disabled ? disabledClasses : enabledClasses} ${className}`}
    >
      {children}
    </button>
  );
};

export default RetroButton;

import React, { useState } from 'react';
import type { Crop, PlayerData } from '../types';
import { RARITY_STYLES } from '../types';
import RetroButton from './RetroButton';

interface ShopModalProps {
  isOpen: boolean;
  onClose: () => void;
  playerData: PlayerData;
  onUpdatePlayerData: (data: PlayerData) => void;
  crops: Record<string, Crop>;
}

type ShopTab = 'buy' | 'sell';

const ShopModal: React.FC<ShopModalProps> = ({ isOpen, onClose, playerData, onUpdatePlayerData, crops }) => {
  const [feedbackMessage, setFeedbackMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [activeTab, setActiveTab] = useState<ShopTab>('buy');

  if (!isOpen) {
    return null;
  }
  
  const showFeedback = (text: string, type: 'success' | 'error') => {
    setFeedbackMessage({ text, type });
    setTimeout(() => setFeedbackMessage(null), 2000);
  };

  const handleBuy = (cropKey: string) => {
    const crop = crops[cropKey];
    if (playerData.silver >= crop.price) {
      const newSilver = playerData.silver - crop.price;
      const newInventory = { ...playerData.inventory };
      const newSementes = { ...newInventory.sementes };
      newSementes[cropKey] = (newSementes[cropKey] || 0) + 1;
      newInventory.sementes = newSementes;
      
      onUpdatePlayerData({ ...playerData, silver: newSilver, inventory: newInventory });
      showFeedback(`🛒 1x ${crop.name} comprado!`, 'success');
    } else {
      showFeedback('❌ Prata insuficiente!', 'error');
    }
  };

  const handleSell = (cropKey: string) => {
    const crop = crops[cropKey];
    const currentAmount = playerData.inventory.colheitas[cropKey] || 0;

    if (currentAmount > 0) {
      const newSilver = playerData.silver + crop.sellPrice;
      const newInventory = { ...playerData.inventory };
      newInventory.colheitas = { ...newInventory.colheitas };
      newInventory.colheitas[cropKey] = currentAmount - 1;

      if (newInventory.colheitas[cropKey] === 0) {
        delete newInventory.colheitas[cropKey];
      }
      onUpdatePlayerData({ ...playerData, silver: newSilver, inventory: newInventory });
      showFeedback(`💰 1x ${crop.name} vendido!`, 'success');
    } else {
      showFeedback('❌ Item esgotado!', 'error');
    }
  };

  const harvestedItems = Object.entries(playerData.inventory.colheitas).filter(([,count]) => count > 0);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 animate-fade-in" role="dialog" aria-modal="true">
      <div className="bg-amber-100 p-6 border-8 border-green-800 rounded-lg max-w-lg w-full text-center shadow-2xl relative">
        <header className="flex justify-between items-start mb-4">
          <h2 className="text-2xl md:text-3xl font-bold text-green-800">Loja</h2>
          <div className="text-lg md:text-xl font-bold flex-shrink-0">
            <span className="flex items-center gap-2 bg-black bg-opacity-20 px-3 py-1 rounded-md text-white">
              <span>🪙</span>
              <span>{playerData.silver}</span>
            </span>
          </div>
        </header>

        {feedbackMessage && (
            <div className={`absolute top-5 right-5 text-white text-sm py-1 px-3 rounded-md animate-fade-in ${feedbackMessage.type === 'error' ? 'bg-red-600' : 'bg-green-600'}`}>
                {feedbackMessage.text}
            </div>
        )}

        <div className="flex gap-2 border-b-4 border-green-800 mb-4">
          <button onClick={() => setActiveTab('buy')} className={`pb-2 px-4 text-xl font-bold transition-colors ${activeTab === 'buy' ? 'text-green-700 border-b-4 border-green-700' : 'text-gray-500'}`}>Comprar</button>
          <button onClick={() => setActiveTab('sell')} className={`pb-2 px-4 text-xl font-bold transition-colors ${activeTab === 'sell' ? 'text-yellow-700 border-b-4 border-yellow-700' : 'text-gray-500'}`}>Vender</button>
        </div>

        <div className="flex flex-col gap-4 max-h-96 overflow-y-auto pr-2">
          {activeTab === 'buy' && Object.entries(crops).map(([key, crop]) => (
            <div key={key} className="flex items-center justify-between w-full p-3 bg-green-200 border-4 border-green-600 rounded-md">
              <div className="flex items-center gap-4">
                <span className="text-4xl" aria-hidden="true">{crop.emoji}</span>
                <div className="text-left">
                  <p className="font-bold text-lg">{crop.name}</p>
                  <p className="text-sm text-gray-700">Preço: {crop.price} 🪙</p>
                </div>
              </div>
              <RetroButton onClick={() => handleBuy(key)} className="bg-green-600 hover:bg-green-700 text-sm p-2 w-28">
                Comprar
              </RetroButton>
            </div>
          ))}
          
          {activeTab === 'sell' && harvestedItems.length > 0 && harvestedItems.map(([key, count]) => {
            const crop = crops[key];
            return (
              <div key={key} className="flex items-center justify-between w-full p-3 bg-yellow-200 border-4 border-yellow-600 rounded-md">
                <div className="flex items-center gap-4">
                  <span className="text-4xl" aria-hidden="true">{crop.emoji}</span>
                  <div className="text-left">
                    <p className="font-bold text-lg">{crop.name} <span className="font-bold text-xl">x{count}</span></p>
                    <p className="text-sm text-gray-700">Venda: {crop.sellPrice} 🪙</p>
                  </div>
                </div>
                <RetroButton onClick={() => handleSell(key)} className="bg-yellow-600 hover:bg-yellow-700 text-sm p-2 w-28">
                  Vender
                </RetroButton>
              </div>
            );
          })}

          {activeTab === 'sell' && harvestedItems.length === 0 && (
            <p className="text-gray-700 my-4">Você não tem itens para vender. Colha algumas plantações primeiro!</p>
          )}
        </div>

        <div className="mt-8">
          <RetroButton onClick={onClose} className="bg-gray-500 hover:bg-gray-600 w-full">
            Voltar
          </RetroButton>
        </div>
      </div>
    </div>
  );
};

export default ShopModal;

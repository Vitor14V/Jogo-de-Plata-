
import React from 'react';
import RetroButton from './RetroButton';
import { CHANGELOG_DATA } from '../data/changelog';

interface MainMenuProps {
  onStart: () => void;
  onContinue: () => void;
  onCredits: () => void;
  onUpdates: () => void;
  continueDisabled: boolean;
}

const MainMenu: React.FC<MainMenuProps> = ({ onStart, onContinue, onCredits, onUpdates, continueDisabled }) => {
  const latestVersion = CHANGELOG_DATA[0]?.version || 'v?.?.?';

  return (
    <div className="flex flex-col items-center justify-center gap-6 w-full animate-fade-in relative">
      <h1 className="text-5xl md:text-7xl font-bold text-green-800 mb-8" style={{ textShadow: '4px 4px 0px #c2b280' }}>
        SilverFarm
      </h1>
      <div className="w-full max-w-sm flex flex-col gap-4">
        <RetroButton onClick={onStart} className="bg-green-600 hover:bg-green-700">
          Iniciar Jogo
        </RetroButton>
        <RetroButton onClick={onContinue} disabled={continueDisabled} className="bg-yellow-600 hover:bg-yellow-700">
          Continuar Jogo
        </RetroButton>
        <RetroButton onClick={onUpdates} className="bg-purple-600 hover:bg-purple-700">
          Atualizações
        </RetroButton>
        <RetroButton onClick={onCredits} className="bg-blue-600 hover:bg-blue-700">
          Créditos
        </RetroButton>
      </div>
       <div className="absolute bottom-4 right-4 text-gray-500 font-bold">
        {latestVersion}
      </div>
    </div>
  );
};

export default MainMenu;

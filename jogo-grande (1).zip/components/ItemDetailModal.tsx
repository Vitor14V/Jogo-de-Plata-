
import React from 'react';
import type { Crop } from '../types';
import { RARITY_STYLES } from '../types';

interface ItemDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  crop: Crop;
  count: number;
  itemType: 'semente' | 'colheita';
}

const ItemDetailModal: React.FC<ItemDetailModalProps> = ({ isOpen, onClose, crop, count, itemType }) => {
  if (!isOpen) {
    return null;
  }

  const rarityStyle = RARITY_STYLES[crop.rarity];
  const rarityBgColor = {
    'Comum': 'bg-gray-300',
    'Incomum': 'bg-green-300',
    'Raro': 'bg-blue-300',
    'Lendário': 'bg-purple-300',
  }[crop.rarity];

  return (
    // Backdrop, handles closing on outside click
    <div 
      className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-[60] p-4 animate-fade-in" 
      onClick={onClose}
      role="dialog" 
      aria-modal="true"
      aria-labelledby="item-detail-title"
    >
      {/* Modal Content, prevents click propagation from closing it */}
      <div 
        className="bg-amber-100 p-5 border-8 border-gray-800 rounded-lg max-w-sm w-full text-left shadow-2xl relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button 
          onClick={onClose} 
          className="absolute top-1 right-2 text-4xl font-bold text-gray-700 hover:text-red-600 transition-colors"
          aria-label="Fechar"
        >
          &times;
        </button>
        
        {/* Header */}
        <header className="flex items-center gap-4 mb-4 border-b-4 border-gray-400 pb-3">
          <span className="text-6xl" aria-hidden="true">{crop.emoji}</span>
          <div>
            <h2 id="item-detail-title" className="text-3xl font-bold text-gray-800">{crop.name}</h2>
            <p className="text-lg text-gray-600">{itemType === 'semente' ? 'Semente' : 'Colheita'}</p>
          </div>
        </header>

        {/* Description */}
        <p className="text-base text-gray-700 mb-5 italic">"{crop.description}"</p>
        
        {/* Details Grid */}
        <div className="space-y-3">
            <div className="flex justify-between items-center text-lg p-2 bg-amber-50 rounded-md">
                <span className="font-bold text-gray-800">Quantidade:</span>
                <span className="font-bold">{count}</span>
            </div>
            <div className="flex justify-between items-center text-lg p-2 bg-amber-50 rounded-md">
                <span className="font-bold text-gray-800">Raridade:</span>
                <span className={`px-2 py-0.5 rounded-md text-sm font-bold ${rarityStyle} ${rarityBgColor}`}>{crop.rarity}</span>
            </div>
             {itemType === 'colheita' && (
                <div className="flex justify-between items-center text-lg p-2 bg-amber-50 rounded-md">
                    <span className="font-bold text-gray-800">Valor de Venda:</span>
                    <span className="font-bold flex items-center gap-1 text-green-700">
                        <span>🪙</span> 
                        {crop.sellPrice}
                    </span>
                </div>
             )}
            <div className="flex justify-between items-center text-lg p-2 bg-amber-50 rounded-md">
                <span className="font-bold text-gray-800">Origem:</span>
                <span className="font-bold text-gray-500">{crop.origin}</span>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ItemDetailModal;

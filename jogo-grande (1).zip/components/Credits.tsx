
import React from 'react';
import RetroButton from './RetroButton';

interface CreditsProps {
  onGoToMenu: () => void;
}

const Credits: React.FC<CreditsProps> = ({ onGoToMenu }) => {
  return (
    <div className="flex flex-col items-center justify-center gap-8 w-full max-w-lg text-center">
      <h1 className="text-5xl md:text-6xl font-bold text-blue-800">Créditos</h1>
      <div className="text-lg md:text-xl space-y-4 bg-blue-100 p-6 border-4 border-gray-800">
        <p>
          <span className="font-bold">SilverFarm</span>
        </p>
        <p>Um jogo feito com carinho.</p>
        <p>Desenvolvido com a ajuda da IA Gemini.</p>
      </div>
      <div className="w-full max-w-sm mt-6">
        <RetroButton onClick={onGoToMenu} className="bg-blue-600 hover:bg-blue-700">
          Voltar
        </RetroButton>
      </div>
    </div>
  );
};

export default Credits;


import React from 'react';
import RetroButton from './RetroButton';
import { CHANGELOG_DATA } from '../data/changelog';

interface ChangelogModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ChangelogModal: React.FC<ChangelogModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 animate-fade-in" role="dialog" aria-modal="true">
      <div className="bg-amber-100 p-6 border-8 border-purple-800 rounded-lg max-w-lg w-full text-left shadow-2xl">
        <h2 className="text-2xl md:text-3xl font-bold text-purple-800 mb-6 text-center">Atualizações do Jogo</h2>
        
        <div className="flex flex-col gap-6 max-h-[24rem] overflow-y-auto pr-3">
            {CHANGELOG_DATA.map((entry) => (
                <div key={entry.version}>
                    <h3 className="text-xl font-bold text-purple-700 flex justify-between items-baseline">
                        <span>{entry.version}</span>
                        <span className="text-sm font-normal text-gray-600">{entry.date}</span>
                    </h3>
                    <ul className="list-disc list-inside mt-2 space-y-1 text-gray-800">
                        {entry.changes.map((change, index) => (
                            <li key={index}>{change}</li>
                        ))}
                    </ul>
                </div>
            ))}
        </div>

        <div className="mt-8">
          <RetroButton onClick={onClose} className="bg-gray-500 hover:bg-gray-600 w-full">
            Fechar
          </RetroButton>
        </div>
      </div>
    </div>
  );
};

export default ChangelogModal;

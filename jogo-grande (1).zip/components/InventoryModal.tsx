
import React, { useState } from 'react';
import type { PlayerInventory, Crop } from '../types';
import { Rarity, RARITY_STYLES } from '../types';
import RetroButton from './RetroButton';
import ItemDetailModal from './ItemDetailModal';

interface InventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  inventory: PlayerInventory;
  crops: Record<string, Crop>;
}

const InventoryModal: React.FC<InventoryModalProps> = ({ isOpen, onClose, inventory, crops }) => {
  const [selectedItem, setSelectedItem] = useState<{ key: string; type: 'semente' | 'colheita' } | null>(null);

  if (!isOpen) {
    return null;
  }

  const handleItemClick = (key: string, type: 'semente' | 'colheita') => {
    setSelectedItem({ key, type });
  };
  
  const handleCloseDetail = () => {
    setSelectedItem(null);
  };
  
  const selectedCrop = selectedItem ? crops[selectedItem.key] : null;
  const selectedCount = selectedItem ? 
    (selectedItem.type === 'semente' ? inventory.sementes[selectedItem.key] : inventory.colheitas[selectedItem.key])
    : 0;

  const seedEntries = Object.entries(inventory.sementes).filter(([, count]) => count > 0);
  const harvestEntries = Object.entries(inventory.colheitas).filter(([, count]) => count > 0);
  
  const totalItems = 
      Object.values(inventory.sementes).reduce((a, b) => a + b, 0) +
      Object.values(inventory.colheitas).reduce((a, b) => a + b, 0);
  const maxCapacity = 200; // Placeholder for future feature

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4 animate-fade-in" role="dialog" aria-modal="true">
        <div className="bg-amber-100 p-6 border-8 border-green-800 rounded-lg max-w-lg w-full text-center shadow-2xl">
          <header className="flex justify-between items-center mb-6">
              <h2 className="text-2xl md:text-3xl font-bold text-green-800">Inventário</h2>
              <div className="text-base md:text-lg font-bold">
                  <span className="bg-black bg-opacity-20 px-3 py-1 rounded-md text-white">
                      Espaço: {totalItems} / {maxCapacity}
                  </span>
              </div>
          </header>

          <div className="flex flex-col gap-6 max-h-[22rem] overflow-y-auto pr-2">
              {/* Seeds Section */}
              <div>
                  <h3 className="text-xl font-bold text-left mb-2 text-green-700 border-b-4 border-green-300 pb-1">Sementes</h3>
                  <div className="flex flex-col gap-2 pt-2">
                      {seedEntries.length > 0 ? (
                          seedEntries.map(([key, count]) => (
                              <button 
                                key={`seed-${key}`} 
                                className="flex items-center justify-between p-2 bg-green-100 border-2 border-green-400 rounded-md text-left w-full hover:bg-green-200 transition-colors"
                                onClick={() => handleItemClick(key, 'semente')}
                                aria-label={`Ver detalhes de Semente de ${crops[key].name}`}
                              >
                                  <div className="flex items-center gap-3">
                                      <span className="text-3xl" aria-hidden="true">{crops[key].emoji}</span>
                                      <span className="font-bold">{crops[key].name}</span>
                                  </div>
                                  <span className="font-bold text-lg">x{count}</span>
                              </button>
                          ))
                      ) : (
                          <p className="text-gray-600 text-left pl-1">Nenhuma semente.</p>
                      )}
                  </div>
              </div>

              {/* Harvests Section */}
              <div>
                  <h3 className="text-xl font-bold text-left mb-2 text-yellow-700 border-b-4 border-yellow-300 pb-1">Colheitas</h3>
                  <div className="flex flex-col gap-2 pt-2">
                      {harvestEntries.length > 0 ? (
                          harvestEntries.map(([key, count]) => {
                              const crop = crops[key];
                              const rarity = crop.rarity || Rarity.Comum;
                              const rarityClass = RARITY_STYLES[rarity];
                              return (
                                  <button 
                                    key={`harvest-${key}`} 
                                    className="flex items-center justify-between p-2 bg-yellow-100 border-2 border-yellow-400 rounded-md text-left w-full hover:bg-yellow-200 transition-colors"
                                    onClick={() => handleItemClick(key, 'colheita')}
                                    aria-label={`Ver detalhes de ${crop.name}`}
                                  >
                                      <div className="flex items-center gap-3">
                                          <span className="text-3xl" aria-hidden="true">{crop.emoji}</span>
                                          <div className="text-left">
                                              <span className="font-bold">{crop.name}</span>
                                              <p className={`text-xs ${rarityClass}`}>{rarity}</p>
                                          </div>
                                      </div>
                                      <span className="font-bold text-lg">x{count}</span>
                                  </button>
                              );
                          })
                      ) : (
                          <p className="text-gray-600 text-left pl-1">Nenhum item colhido.</p>
                      )}
                  </div>
              </div>
          </div>

          <div className="mt-8">
            <RetroButton onClick={onClose} className="bg-gray-500 hover:bg-gray-600 w-full">
              Fechar
            </RetroButton>
          </div>
        </div>
      </div>
      {selectedItem && selectedCrop && (
        <ItemDetailModal 
          isOpen={!!selectedItem}
          onClose={handleCloseDetail}
          crop={selectedCrop}
          count={selectedCount || 0}
          itemType={selectedItem.type}
        />
      )}
    </>
  );
};

export default InventoryModal;
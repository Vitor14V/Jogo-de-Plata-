
import { Crop, Rarity } from '../types';

export const CROP_DATA: Record<string, Crop> = {
  wheat: {
    name: 'Trigo',
    emoji: '🌾',
    growthTime: 40, // seconds
    sellPrice: 18, // silver gained when selling
    price: 10, // silver cost to buy
    rarity: Rarity.Comum,
    description: 'Um grão clássico, a base de muitas receitas. Essencial para qualquer fazendeiro.',
    origin: 'Coletado na sua Fazenda',
  },
  corn: {
    name: 'Milho',
    emoji: '🌽',
    growthTime: 60, // seconds
    sellPrice: 25, // silver gained when selling
    price: 15, // silver cost to buy
    rarity: Rarity.Comum,
    description: 'Espigas douradas e doces, um favorito do verão que cresce rapidamente sob o sol.',
    origin: 'Coletado na sua Fazenda',
  },
  potato: {
    name: 'Batata',
    emoji: '🥔',
    growthTime: 120, // seconds
    sellPrice: 35, // silver gained when selling
    price: 20, // silver cost to buy
    rarity: Rarity.Comum,
    description: 'Um tubérculo versátil e resistente. Pode ser cozido, frito ou assado. Cresce feliz debaixo da terra.',
    origin: 'Coletado na sua Fazenda',
  },
};

export interface ChangelogEntry {
    version: string;
    date: string;
    changes: string[];
}

export const CHANGELOG_DATA: ChangelogEntry[] = [
    {
        version: 'V0',
        date: 'Hoje',
        changes: [
            'Botão de "Atualizações" movido para o Menu Principal.',
            'Versão do jogo agora visível no Menu Principal.',
            'Ajuste no layout dos botões na tela da fazenda.',
        ],
    },
    {
        version: 'v0.2.0',
        date: 'Hoje',
        changes: [
            'Adicionado Inventário para Colheitas.',
            'Loja agora tem abas de Comprar e Vender.',
            'Jogadores podem vender itens colhidos por prata.',
            'Adicionado botão de Atualizações e changelog.',
            'Itens colhidos agora mostram raridade no inventário.',
        ],
    },
    {
        version: 'v0.1.0',
        date: 'Ontem',
        changes: [
            'Lançamento da versão inicial de SilverFarm!',
            'Sistema de plantio com 6 canteiros.',
            'Mecânica de desbloquear canteiros com prata.',
            'Sistema de crescimento das plantas em tempo real.',
            'Salvamento de progresso localmente no navegador.'
        ],
    },
];
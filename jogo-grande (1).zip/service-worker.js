const CACHE_NAME = 'silverfarm-cache-v2'; // Versão do cache incrementada para forçar a atualização.

// Lista completa de recursos para garantir que a aplicação funcione 100% offline.
const URLS_TO_CACHE = [
  // Core App Shell
  '/',
  '/index.html',
  '/manifest.json',

  // Ícones da Aplicação (garanta que estes arquivos existam na raiz do seu projeto)
  '/icon-192x192.png',
  '/icon-512x512.png',

  // Código Fonte da Aplicação
  '/index.tsx',
  '/App.tsx',
  '/types.ts',
  '/metadata.json',
  '/services/storageService.ts',
  '/data/crops.ts',
  '/data/changelog.ts',
  '/components/RetroButton.tsx',
  '/components/MainMenu.tsx',
  '/components/PlayerCreation.tsx',
  '/components/Farm.tsx',
  '/components/Credits.tsx',
  '/components/SeedSelectionModal.tsx',
  '/components/ShopModal.tsx',
  '/components/InventoryModal.tsx',
  '/components/ChangelogModal.tsx',
  '/components/ItemDetailModal.tsx',

  // Dependências Externas
  'https://cdn.tailwindcss.com',
  'https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap',
  'https://fonts.gstatic.com/s/pressstart2p/v15/e3t4euO8T-267oIAQAu6jDQyK3nVivM.woff2', // Cache do arquivo de fonte
  'https://fonts.gstatic.com/s/pressstart2p/v15/e3t4euO8T-267oIAQAu6jDQyK3nVivQ.woff2', // Cache do arquivo de fonte
  'https://esm.sh/react@18.2.0',
  'https://esm.sh/react-dom@18.2.0/client',
  'https://esm.sh/react@18.2.0/',
  'https://esm.sh/react-dom@18.2.0/'
];

// Evento de instalação: abre um cache e adiciona todos os URLs a ele.
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Cache aberto, armazenando arquivos para modo offline.');
        return cache.addAll(URLS_TO_CACHE);
      })
      .catch(err => {
        console.error('Falha ao armazenar arquivos em cache durante a instalação:', err);
      })
  );
  self.skipWaiting();
});

// Evento de fetch: serve do cache primeiro (estratégia cache-first).
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Encontrado no cache - retorna a resposta do cache.
        if (response) {
          return response;
        }
        // Não está no cache - busca na rede.
        return fetch(event.request);
      }
    )
  );
});

// Evento de ativação: limpa caches antigos para evitar conflitos e garantir que a nova versão seja usada.
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('Deletando cache antigo:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  return self.clients.claim();
});